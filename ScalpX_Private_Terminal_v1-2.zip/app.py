import streamlit as st
import pandas as pd
import requests
import plotly.graph_objects as go
from datetime import datetime, timezone

st.set_page_config(page_title="ScalpX | Private Terminal", page_icon="⚡", layout="wide")
st.markdown("""
<style>
.stApp { background: #080b12; color: #e7edf7; }
[data-testid="stSidebar"] {background:#0d121d; border-right:1px solid #202b3b;}
.block-container {padding-top:1.3rem; padding-bottom:2rem;}
h1,h2,h3 {color:#edf4ff;}
div[data-testid="stMetric"] {background:#101725; border:1px solid #202d40; padding:14px 16px; border-radius:14px;}
div[data-testid="stMetricLabel"] {color:#9caec7;}
div[data-testid="stMetricValue"] {color:#f3f7ff;}
.signal-card {background:linear-gradient(145deg,#111a29,#0d131e);border:1px solid #263449;border-radius:16px;padding:16px;margin:6px 0 12px;}
.pill {display:inline-block;border-radius:999px;padding:4px 10px;background:#143b2c;color:#67e6a6;font-size:12px;font-weight:700;}
.muted {color:#8da0ba;}
</style>
""", unsafe_allow_html=True)

API="https://api.binance.com"
st.title("⚡ ScalpX")
st.caption("PRIVATE SCALPING TERMINAL  •  LIVE MARKET DATA  •  PAPER MODE")

@st.cache_data(ttl=12)
def ticker_data():
    res=requests.get(API+"/api/v3/ticker/24hr",timeout=15); res.raise_for_status()
    d=pd.DataFrame(res.json())
    d=d[d.symbol.str.endswith("USDT",na=False)]
    exclusions=("UPUSDT","DOWNUSDT","BULLUSDT","BEARUSDT")
    d=d[~d.symbol.str.endswith(exclusions)]
    for col in ["lastPrice","priceChangePercent","quoteVolume"]:
        d[col]=pd.to_numeric(d[col],errors="coerce")
    return d.sort_values("quoteVolume",ascending=False)

@st.cache_data(ttl=8)
def klines(symbol, interval, limit=220):
    r=requests.get(API+"/api/v3/klines",params={"symbol":symbol,"interval":interval,"limit":limit},timeout=15)
    r.raise_for_status()
    x=pd.DataFrame(r.json(),columns=["t","o","h","l","c","v","ct","qv","n","tb","tq","ig"])
    for col in ["o","h","l","c","v"]: x[col]=pd.to_numeric(x[col],errors="coerce")
    x["time"]=pd.to_datetime(x.t,unit="ms",utc=True)
    x["ema9"]=x.c.ewm(span=9,adjust=False).mean()
    x["ema20"]=x.c.ewm(span=20,adjust=False).mean()
    x["ema33"]=x.c.ewm(span=33,adjust=False).mean()
    x["ema200"]=x.c.ewm(span=200,adjust=False).mean()
    delta=x.c.diff()
    up=delta.clip(lower=0).rolling(14).mean()
    dn=(-delta.clip(upper=0)).rolling(14).mean()
    x["rsi"]=100-(100/(1+up/dn.replace(0,pd.NA)))
    return x

def score_signal(x):
    a=x.iloc[-1]; prev=x.iloc[-2]
    score=0; notes=[]
    if a.c>a.ema9>a.ema20: score+=25; notes.append("Price/EMA bullish alignment")
    elif a.ema9>a.ema20: score+=15; notes.append("EMA9 above EMA20")
    if a.ema9>a.ema33: score+=15; notes.append("EMA9 above EMA33")
    if pd.notna(a.rsi) and 50<=a.rsi<=67: score+=20; notes.append("RSI momentum zone")
    elif pd.notna(a.rsi) and 45<=a.rsi<50: score+=8; notes.append("RSI recovering")
    if a.c>a.ema200: score+=15; notes.append("Price above EMA200")
    if a.v>prev.v: score+=10; notes.append("Volume increased")
    if a.c>prev.c: score+=5; notes.append("Latest close higher")
    return min(score,100),notes

# Session-only paper ledger
for key,default in [("cash",1000.0),("positions",{}),("history",[]),("start_equity",1000.0)]:
    if key not in st.session_state: st.session_state[key]=default

with st.sidebar:
    st.header("⚙️ Settings")
    balance=st.number_input("Starting balance (USDT)",100.0,100000.0,1000.0,step=100.0)
    amount=st.number_input("Paper trade size (USDT)",10.0,10000.0,100.0,step=10.0)
    target=st.number_input("Take profit (%)",0.05,5.0,0.30,step=0.05)
    stop=st.number_input("Stop loss (%)",0.05,5.0,0.25,step=0.05)
    fee=st.number_input("Estimated fee per side (%)",0.0,1.0,0.10,step=0.01)
    tf=st.selectbox("Chart timeframe",["1m","3m","5m","15m","1h"],index=2)
    scan_count=st.slider("Scan top liquid USDT pairs",10,60,20,5)
    if st.button("Reset paper account",use_container_width=True):
        st.session_state.cash=float(balance); st.session_state.positions={}; st.session_state.history=[]; st.session_state.start_equity=float(balance); st.rerun()
    st.caption("No API key. No real orders.")

try:
    tick=ticker_data()
except Exception as e:
    st.error("Public Binance data load nahi ho saka. Internet check karke Retry karein.")
    st.exception(e); st.stop()

price_map=dict(zip(tick.symbol,tick.lastPrice))
pos_value=sum(p["qty"]*price_map.get(s,p["entry"]) for s,p in st.session_state.positions.items())
equity=st.session_state.cash+pos_value
pnl=equity-st.session_state.start_equity
closed=st.session_state.history
wins=sum(t["net"]>0 for t in closed)
winrate=100*wins/len(closed) if closed else 0

# auto target/stop exit when page refreshes
exit_events=[]
for symbol,p in list(st.session_state.positions.items()):
    live=price_map.get(symbol)
    if live is None: continue
    move=(live/p["entry"]-1)*100
    if move>=p["target"] or move<=-p["stop"]:
        proceeds=live*p["qty"]; sellfee=proceeds*fee/100
        net=proceeds-sellfee-(p["cost"]+p["buyfee"])
        st.session_state.cash += proceeds-sellfee
        st.session_state.history.append({"Coin":symbol,"Entry":p["entry"],"Exit":live,"Net P/L":net,"Exit type":"TP" if move>=p["target"] else "SL","Time":datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")})
        del st.session_state.positions[symbol]; exit_events.append(f"{symbol} {net:+.4f} USDT")
if exit_events: st.toast("Auto exit: "+", ".join(exit_events))

# metrics
m=st.columns(5)
m[0].metric("Paper Equity",f"${equity:,.2f}",f"{pnl:+.2f}")
m[1].metric("Cash Available",f"${st.session_state.cash:,.2f}")
m[2].metric("Open Positions",len(st.session_state.positions))
m[3].metric("Closed Trades",len(closed))
m[4].metric("Win Rate",f"{winrate:.1f}%" if closed else "—")
st.divider()

left,right=st.columns([1.05,1.45],gap="large")
with left:
    st.subheader("🔎 Coin Scanner")
    candidates=tick.head(scan_count)
    signals=[]
    progress=st.progress(0)
    for i,(_,row) in enumerate(candidates.iterrows()):
        try:
            x=klines(row.symbol,tf,210)
            s,why=score_signal(x)
            signals.append({"Symbol":row.symbol,"Price":row.lastPrice,"24h %":row.priceChangePercent,"Volume USDT":row.quoteVolume,"Score":s,"RSI":x.iloc[-1].rsi,"Why":", ".join(why)})
        except: pass
        progress.progress((i+1)/max(1,len(candidates)))
    progress.empty()
    sig=pd.DataFrame(signals)
    if not sig.empty:
        sig=sig.sort_values(["Score","Volume USDT"],ascending=False)
        st.dataframe(sig[["Symbol","Price","24h %","Score","RSI"]],use_container_width=True,hide_index=True)
        top=sig.iloc[0]
        st.markdown(f"""<div class="signal-card"><span class="pill">TOP WATCH</span><h3>{top['Symbol']} &nbsp; • &nbsp; Score {int(top['Score'])}/100</h3><div class="muted">{top['Why']}</div></div>""",unsafe_allow_html=True)
    else: st.info("Signals load nahi ho rahe. Retry.")

with right:
    st.subheader("📈 Chart & Signal Details")
    all_symbols=tick.symbol.tolist()
    preferred="BTCUSDT" if "BTCUSDT" in all_symbols else all_symbols[0]
    chosen=st.selectbox("Coin",all_symbols,index=all_symbols.index(preferred))
    try:
        x=klines(chosen,tf,250); score,why=score_signal(x)
        st.markdown(f"**{chosen}**  •  Signal score **{score}/100**  •  RSI **{x.iloc[-1].rsi:.1f}**")
        chart=go.Figure()
        chart.add_trace(go.Candlestick(x=x.time,open=x.o,high=x.h,low=x.l,close=x.c,name="Candles"))
        for col,label in [("ema9","EMA 9"),("ema20","EMA 20"),("ema33","EMA 33"),("ema200","EMA 200")]:
            chart.add_trace(go.Scatter(x=x.time,y=x[col],mode="lines",name=label))
        chart.add_trace(go.Bar(x=x.time,y=x.v,name="Volume",yaxis="y2",opacity=.20))
        chart.update_layout(template="plotly_dark",height=470,xaxis_rangeslider_visible=False,yaxis2=dict(overlaying="y",side="right",showgrid=False),legend=dict(orientation="h"),margin=dict(l=10,r=10,t=20,b=10))
        st.plotly_chart(chart,use_container_width=True)
        st.caption("Score is a rule-based indicator, not a proven probability of the next candle.")
    except Exception as e: st.warning(f"Chart unavailable: {e}")

st.divider()
st.subheader("🧪 Paper Trade Controls")
selected_price=float(price_map.get(chosen,0))
c1,c2,c3=st.columns([1,1,1.5])
with c1:
    if st.button(f"🟢 PAPER BUY {chosen}",use_container_width=True,disabled=(chosen in st.session_state.positions or st.session_state.cash<amount*(1+fee/100))):
        qty=amount/selected_price; buyfee=amount*fee/100
        st.session_state.cash-=amount+buyfee
        st.session_state.positions[chosen]={"entry":selected_price,"qty":qty,"cost":amount,"buyfee":buyfee,"target":target,"stop":stop,"opened":datetime.now(timezone.utc).isoformat()}
        st.success(f"Paper BUY {chosen} @ {selected_price}"); st.rerun()
with c2:
    if st.button(f"🔴 PAPER SELL {chosen}",use_container_width=True,disabled=chosen not in st.session_state.positions):
        p=st.session_state.positions[chosen]; proceeds=selected_price*p["qty"]; sellfee=proceeds*fee/100
        net=proceeds-sellfee-(p["cost"]+p["buyfee"])
        st.session_state.cash+=proceeds-sellfee
        st.session_state.history.append({"Coin":chosen,"Entry":p["entry"],"Exit":selected_price,"Net P/L":net,"Exit type":"Manual","Time":datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")})
        del st.session_state.positions[chosen]; st.success(f"Closed. Net P/L {net:+.4f} USDT"); st.rerun()
with c3:
    st.info(f"Trade size: ${amount:,.2f} | Target: +{target}% | Stop: -{stop}% | Fee: {fee}% per side")

st.subheader("Open Positions")
if st.session_state.positions:
    open_rows=[]
    for sym,p in st.session_state.positions.items():
        lp=price_map.get(sym,p["entry"]); pct=(lp/p["entry"]-1)*100
        open_rows.append({"Coin":sym,"Entry":p["entry"],"Live":lp,"Move %":pct,"Quantity":p["qty"],"TP %":p["target"],"SL %":p["stop"]})
    st.dataframe(pd.DataFrame(open_rows),use_container_width=True,hide_index=True)
else: st.caption("Abhi koi open paper position nahi.")

st.subheader("Trade History")
if st.session_state.history:
    st.dataframe(pd.DataFrame(st.session_state.history).iloc[::-1],use_container_width=True,hide_index=True)
else: st.caption("Closed trades abhi yahan record nahi huay.")

st.caption("Prototype v1 • Paper trading only • Data from Binance public endpoints • Session data resets on app restart • Refresh page to update scanner and trigger auto-exits")
