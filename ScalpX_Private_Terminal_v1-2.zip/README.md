# ScalpX Private Scalping Terminal - v1

Paper-trading prototype with dark dashboard.

### Included
- Binance public market data only (no account/API key)
- Coin scanner for liquid USDT pairs
- Heuristic bullish score (not a prediction probability)
- Candles + EMA 9/20/33/200 + volume chart
- Paper Buy/Sell buttons
- Target/Stop exits checked on app refresh
- Paper equity, cash, open positions, history and win rate

### Setup (Windows)
1. Install Python 3.10+ from python.org (check "Add Python to PATH").
2. Extract ZIP to a folder.
3. Open Command Prompt in that folder.
4. Run:
   `python -m pip install -r requirements.txt`
5. Run:
   `python -m streamlit run app.py`
6. The terminal will print a local URL (typically `http://localhost:8501`). Open it in a browser.

No Binance login, private API key, or real orders are used.

### Limitations
- Scanner fetches klines sequentially; can take time.
- Auto-exits are evaluated when the app refreshes/reruns; no background engine yet.
- Session-state ledger is not persistent across app restarts.
- The score is heuristic and not statistically calibrated.
- Fees, spread, and slippage are estimates.
